import { supportedLanguages } from "@/lib/constants";
import {
  CaseStudyArea,
  CaseStudyDetailViewModel,
  CaseStudyListItemViewModel,
  CaseStudyProgressRecord,
  CaseStudyProgressStatus,
  CaseStudyRecord,
  CaseStudyTranslationRecord,
} from "@/lib/eportfolio/types";
import { prisma } from "@/lib/prisma";

function normalizeOptionalText(value: string | null | undefined) {
  const trimmed = value?.trim();

  return trimmed && trimmed.length > 0 ? trimmed : null;
}

function pickTranslation(
  translations: CaseStudyTranslationRecord[],
  locale: string,
): CaseStudyTranslationRecord | null {
  const localeTranslation = translations.find((translation) => translation.language === locale);

  if (localeTranslation) {
    return localeTranslation;
  }

  const englishTranslation = translations.find((translation) => translation.language === "en");

  if (englishTranslation) {
    return englishTranslation;
  }

  return translations.at(0) ?? null;
}

function mapArea(area: string): CaseStudyArea {
  switch (area) {
    case "environmental":
      return "environmental";

    case "social":
      return "social";

    case "governance":
      return "governance";

    default:
      return "cross-cutting";
  }
}

function parseKeyTakeaways(value: unknown): string[] {
  if (!Array.isArray(value)) {
    return [];
  }

  return value.filter((item): item is string => typeof item === "string" && item.trim().length > 0);
}

function buildSummary(translation: CaseStudyTranslationRecord | null): string | null {
  const summary = normalizeOptionalText(translation?.summary);

  if (summary) {
    return summary;
  }

  const content = normalizeOptionalText(translation?.content);

  if (content) {
    return content.slice(0, 180);
  }

  return null;
}

function mapProgressStatus(status?: string | null): CaseStudyProgressStatus {
  if (status === "completed") {
    return "completed";
  }

  if (status === "in_progress") {
    return "in_progress";
  }

  return "not_started";
}

function getProgressState(progress: CaseStudyProgressRecord[]) {
  const latestProgress = progress.at(0);
  const status = mapProgressStatus(latestProgress?.status);

  return {
    status,
    isCompleted: status === "completed",
    startedAt: latestProgress?.startedAt?.toISOString() ?? null,
    lastOpenedAt: latestProgress?.lastOpenedAt?.toISOString() ?? null,
    completedAt: latestProgress?.completedAt?.toISOString() ?? null,
  };
}

function mapCaseStudyToListItem(
  caseStudy: CaseStudyRecord,
  locale: string,
): CaseStudyListItemViewModel {
  const translation = pickTranslation(caseStudy.translations, locale);

  const progress = getProgressState(caseStudy.userProgress);

  return {
    slug: caseStudy.slug,
    title: translation?.title ?? caseStudy.slug,
    summary: buildSummary(translation),
    area: mapArea(caseStudy.area),
    organization: translation?.organization ?? null,
    industry: translation?.industry ?? null,
    isFeatured: caseStudy.isFeatured,
    status: progress.status,
    isCompleted: progress.isCompleted,
    startedAt: progress.startedAt,
    lastOpenedAt: progress.lastOpenedAt,
    completedAt: progress.completedAt,
  };
}

function mapCaseStudyToDetail(
  caseStudy: CaseStudyRecord,
  locale: string,
): CaseStudyDetailViewModel {
  const translation = pickTranslation(caseStudy.translations, locale);

  const progress = getProgressState(caseStudy.userProgress);

  return {
    slug: caseStudy.slug,
    title: translation?.title ?? caseStudy.slug,
    summary: buildSummary(translation),
    content: normalizeOptionalText(translation?.content),
    area: mapArea(caseStudy.area),
    organization: translation?.organization ?? null,
    industry: translation?.industry ?? null,
    isFeatured: caseStudy.isFeatured,
    keyTakeaways: parseKeyTakeaways(translation?.keyTakeaways),
    status: progress.status,
    isCompleted: progress.isCompleted,
    startedAt: progress.startedAt,
    lastOpenedAt: progress.lastOpenedAt,
    completedAt: progress.completedAt,
  };
}

export async function getAllCaseStudies(params: { locale: string; userId: string }) {
  const caseStudies = await prisma.caseStudy.findMany({
    where: {
      status: "published",
    },
    select: {
      id: true,
      slug: true,
      area: true,
      isFeatured: true,
      translations: {
        where: {
          language: {
            in: supportedLanguages,
          },
        },
        select: {
          language: true,
          title: true,
          summary: true,
          content: true,
          keyTakeaways: true,
          organization: true,
          industry: true,
        },
      },
      userProgress: {
        where: {
          userId: params.userId,
        },
        select: {
          status: true,
          startedAt: true,
          lastOpenedAt: true,
          completedAt: true,
        },
        orderBy: [
          {
            updatedAt: "desc",
          },
        ],
        take: 1,
      },
    },
    orderBy: [
      {
        isFeatured: "desc",
      },
      {
        sortOrder: "asc",
      },
      {
        createdAt: "desc",
      },
    ],
  });

  return caseStudies.map((caseStudy) => mapCaseStudyToListItem(caseStudy, params.locale));
}

export async function getCaseStudyDetail(params: { locale: string; userId: string; slug: string }) {
  const caseStudy = await prisma.caseStudy.findFirst({
    where: {
      slug: params.slug,
      status: "published",
    },
    select: {
      id: true,
      slug: true,
      area: true,
      isFeatured: true,
      translations: {
        where: {
          language: {
            in: [params.locale, "en"],
          },
        },
        select: {
          language: true,
          title: true,
          summary: true,
          content: true,
          keyTakeaways: true,
          organization: true,
          industry: true,
        },
      },
      userProgress: {
        where: {
          userId: params.userId,
        },
        select: {
          status: true,
          startedAt: true,
          lastOpenedAt: true,
          completedAt: true,
        },
        orderBy: [
          {
            updatedAt: "desc",
          },
        ],
        take: 1,
      },
    },
  });

  if (!caseStudy) {
    return null;
  }

  return mapCaseStudyToDetail(caseStudy, params.locale);
}
